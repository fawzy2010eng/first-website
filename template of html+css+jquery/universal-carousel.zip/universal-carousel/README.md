# uniСarousel
uniСarousel is a universal jQuery Carousel Plugin with many useful features.
For more details see Live Preview - https://stroim-web.ru/demo/uni-carousel.
